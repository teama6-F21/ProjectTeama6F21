


function hMenu() {
   ChangeForm(Form2)
}

