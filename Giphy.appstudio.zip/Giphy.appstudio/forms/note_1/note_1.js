giphyBtn.onclick=function(){
  ChangeForm(giphy_page)
}