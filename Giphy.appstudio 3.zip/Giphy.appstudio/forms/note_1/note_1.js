let note_1_text
let URL = "https://api.giphy.com/v1/gifs/trending?api_key=9wIUIDtOHk9Uxbvla4hj7MOBPtRtpRYs&limit=20&offset=5&rating=g&random_id=e826c9fc5c929e0d6c6d423841a282aa&bundle=messaging_non_clips"
let giphyURLs

function getGiphy() {
  // let key = 'c515880619500d7f6d1e3731af1c40a7' 
  fetch(URL)  
  .then(function(resp) { return resp.json() }) // Convert data to json
  .then(function(data) {
      freeData(data) 
    })
  .catch(function() {
    // catch any errors
  })
}
function freeData(apiData) {
    // just getting temp for proof of concept
    console.log(`in freeData, main.temp is ${apiData.data[0].images.original.url}`)
    // put api data into global variable so can use in other forms
    giphyURLs = apiData  
}


note_1.onshow=function(){
  txt1_contents.style.height="250px"
  getGiphy()
}

saveBtn1.onclick=function(){
  note_1_text=text.value
  console.log(note_1_text)
}
giphyBtnn.onclick=function(){
  ChangeForm(giphy_page)
}
