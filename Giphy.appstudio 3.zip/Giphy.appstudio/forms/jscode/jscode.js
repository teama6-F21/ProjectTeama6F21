function hMenu(note){
 ChangeForm(note)
}