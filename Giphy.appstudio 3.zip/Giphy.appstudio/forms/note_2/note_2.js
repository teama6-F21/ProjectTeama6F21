giphyBtn2.onclick=function(){
  ChangeForm(giphy_page)
}

note_2.onshow=function(){
  txt2_contents.style.height="250px"
  getGiphy()
}

saveBtn2.onclick=function(){
  note_2_text=text.value
  console.log(note_2_text)
}