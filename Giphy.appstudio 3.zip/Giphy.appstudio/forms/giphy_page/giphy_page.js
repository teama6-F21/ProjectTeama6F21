backBtn.onclick=function(){
  ChangeForm(note_1)
}

/* 
giphy_page.onclick=function(){
 gif1.src="https://media4.giphy.com/media/XtydbjSSwkC7K2zBTH/giphy.gif?cid=9c74a86e9t1plkyz6zj7i029nodvg098wjle5633qzh8eyqp&rid=giphy.gif&ct=g"
 gif2.src="https://media1.giphy.com/media/l4KibWpBGWchSqCRy/giphy.gif?cid=9c74a86e9t1plkyz6zj7i029nodvg098wjle5633qzh8eyqp&rid=giphy.gif&ct=g"
 gif3.src="https://media0.giphy.com/media/jluHLy0OgYuJvbTRrA/giphy.gif?cid=9c74a86e9t1plkyz6zj7i029nodvg098wjle5633qzh8eyqp&rid=giphy.gif&ct=g"
 gif4.src="https://media2.giphy.com/media/S9oNGC1E42VT2JRysv/giphy.gif?cid=9c74a86e9t1plkyz6zj7i029nodvg098wjle5633qzh8eyqp&rid=giphy.gif&ct=g"
 gif5.src="https://media1.giphy.com/media/S100e4ef9mDleByH8T/giphy.gif?cid=9c74a86e9t1plkyz6zj7i029nodvg098wjle5633qzh8eyqp&rid=giphy.gif&ct=g"
 gif6.src="https://media2.giphy.com/media/NEvPzZ8bd1V4Y/giphy.gif?cid=9c74a86e9t1plkyz6zj7i029nodvg098wjle5633qzh8eyqp&rid=giphy.gif&ct=g"
}
*/

giphy_page.onshow=function(){
 HTMLgif1.innerHTML = ‘<div class=“video-responsive”><iframe width=“320" height=“240” src=“https://media1.giphy.com/media/l2QZZMUmvtFYYBUWY/giphy.gif?cid=9c74a86elffjdhf2w5i05iy6820t820ybr41os65vl70xge9&rid=giphy.gif&ct=g”></div></iframe>’
 
 /*
 let temp = giphyURLs.data[0].images.original.url
 console.log(temp)
 vdo1.src=temp
  vdo1.play()
 */
}
