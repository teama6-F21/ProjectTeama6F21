giphyBtn3.onclick=function(){
  ChangeForm(giphy_page)
}

note_3.onshow=function(){
  txt3_contents.style.height="250px"
  getGiphy()
}

saveBtn3.onclick=function(){
  note_3_text=text.value
  console.log(note_3_text)
}